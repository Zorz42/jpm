# jpm

JPM stands for Jaclang Package Manager.

With jpm you can install libraries for jaclang, and their dependencies. Jpm has somewhat similar system than apt. For usage just type jpm in the terminal after install.

jpm is by default installed alongside jaclang. (When jaclang is installing it will also install jpm)

STANDALONE INSTALATION PROCESS:
 - download jpm
 - go to jpm directory with terminal
 - installation script supports python2 and python3
 - if you do not have python installed install python3, or python2 (python3 is recomended)
 - then type python3 install.py or python install.py depending on what python you have installed
 - follow the instructions that get printed
 - jaclang will be installed on /usr/local/bin/jpm-sources
